package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int[][] dD = new int[8][5];
        for (int i = 0; i < dD.length; i++) {
            for (int j = 0; j < dD[i].length; j++) {
                dD[i][j] = (int) (Math.random() * 90 + 9);
            }
        }
        for (int i = 0; i < dD.length; i++) {
            for (int j = 0; j < dD[i].length; j++) {
                System.out.print(dD[i][j] + "\t ");
            }
            System.out.println();
        }
    }
}
